--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test_task;
--
-- Name: test_task; Type: DATABASE; Schema: -; Owner: test_admin
--

CREATE DATABASE test_task WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251' LC_CTYPE = 'Russian_Russia.1251';


ALTER DATABASE test_task OWNER TO test_admin;

\connect test_task

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tst; Type: SCHEMA; Schema: -; Owner: test_admin
--

CREATE SCHEMA tst;


ALTER SCHEMA tst OWNER TO test_admin;

--
-- Name: lo; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS lo WITH SCHEMA public;


--
-- Name: EXTENSION lo; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION lo IS 'Large Object maintenance';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: add_new_user(character varying, character varying, character varying); Type: PROCEDURE; Schema: tst; Owner: postgres
--

CREATE PROCEDURE tst.add_new_user(new_login character varying, new_pswd character varying, new_user_name character varying)
    LANGUAGE sql
    AS $$WITH ins_new_user AS (
INSERT INTO tst.users(login, pswd, role_id, state_id) 
VALUES (new_login, CRYPT(new_pswd,GEN_SALT('md5')), 2, 1)
RETURNING user_id)
INSERT INTO tst.user_info(user_id, user_name)
SELECT user_id, new_user_name from ins_new_user$$;


ALTER PROCEDURE tst.add_new_user(new_login character varying, new_pswd character varying, new_user_name character varying) OWNER TO postgres;

--
-- Name: change_user_password(integer, character varying); Type: PROCEDURE; Schema: tst; Owner: test_admin
--

CREATE PROCEDURE tst.change_user_password(in_user_id integer, new_pswd character varying)
    LANGUAGE sql
    AS $$
UPDATE tst.users SET pswd = CRYPT(new_pswd,GEN_SALT('md5')) 
WHERE user_id=in_user_id
$$;


ALTER PROCEDURE tst.change_user_password(in_user_id integer, new_pswd character varying) OWNER TO test_admin;

--
-- Name: delete_user(integer); Type: PROCEDURE; Schema: tst; Owner: test_admin
--

CREATE PROCEDURE tst.delete_user(deleted_id integer)
    LANGUAGE sql
    AS $$UPDATE tst.users SET state_id = 2 WHERE user_id = deleted_id$$;


ALTER PROCEDURE tst.delete_user(deleted_id integer) OWNER TO test_admin;

--
-- Name: get_user_info(character varying, character varying); Type: FUNCTION; Schema: tst; Owner: test_admin
--

CREATE FUNCTION tst.get_user_info(in_login character varying, in_pswd character varying) RETURNS TABLE(user_id integer, login character varying, user_name character varying, user_photo bytea, role_name character varying)
    LANGUAGE sql
    AS $$ SELECT u.user_id, u.login, ui.user_name, ui.user_photo, r.role_name
FROM tst.users AS u
LEFT JOIN tst.user_info AS ui
ON u.user_id=ui.user_id
LEFT JOIN tst.roles AS r
ON u.role_id=r.role_id
WHERE u.login = in_login AND u.pswd = CRYPT(in_pswd, u.pswd) AND u.state_id=1
$$;


ALTER FUNCTION tst.get_user_info(in_login character varying, in_pswd character varying) OWNER TO test_admin;

--
-- Name: get_users_info(); Type: FUNCTION; Schema: tst; Owner: test_admin
--

CREATE FUNCTION tst.get_users_info() RETURNS TABLE(user_id integer, login character varying, user_name character varying, is_admin boolean)
    LANGUAGE sql
    AS $$ SELECT u.user_id, u.login, ui.user_name, r.is_admin
FROM tst.users AS u
LEFT JOIN tst.user_info AS ui
ON u.user_id=ui.user_id
LEFT JOIN tst.roles AS r
ON u.role_id=r.role_id
WHERE u.state_id=1
$$;


ALTER FUNCTION tst.get_users_info() OWNER TO test_admin;

--
-- Name: update_user_password(integer, character varying); Type: PROCEDURE; Schema: tst; Owner: test_admin
--

CREATE PROCEDURE tst.update_user_password(in_user_id integer, new_pswd character varying)
    LANGUAGE sql
    AS $$
UPDATE tst.users SET pswd = CRYPT(new_pswd,GEN_SALT('md5')) 
WHERE user_id=in_user_id AND pswd = CRYPT(new_pswd, pswd)
$$;


ALTER PROCEDURE tst.update_user_password(in_user_id integer, new_pswd character varying) OWNER TO test_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: posts; Type: TABLE; Schema: tst; Owner: test_admin
--

CREATE TABLE tst.posts (
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    post text NOT NULL,
    post_date date NOT NULL
);


ALTER TABLE tst.posts OWNER TO test_admin;

--
-- Name: posts_post_id_seq; Type: SEQUENCE; Schema: tst; Owner: test_admin
--

CREATE SEQUENCE tst.posts_post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.posts_post_id_seq OWNER TO test_admin;

--
-- Name: posts_post_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: test_admin
--

ALTER SEQUENCE tst.posts_post_id_seq OWNED BY tst.posts.post_id;


--
-- Name: roles; Type: TABLE; Schema: tst; Owner: test_admin
--

CREATE TABLE tst.roles (
    role_id smallint NOT NULL,
    role_name character varying(10) NOT NULL,
    is_admin boolean NOT NULL
);


ALTER TABLE tst.roles OWNER TO test_admin;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: tst; Owner: test_admin
--

CREATE SEQUENCE tst.roles_role_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.roles_role_id_seq OWNER TO test_admin;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: test_admin
--

ALTER SEQUENCE tst.roles_role_id_seq OWNED BY tst.roles.role_id;


--
-- Name: state_list; Type: TABLE; Schema: tst; Owner: test_admin
--

CREATE TABLE tst.state_list (
    state_id smallint NOT NULL,
    state_name character varying(50) NOT NULL
);


ALTER TABLE tst.state_list OWNER TO test_admin;

--
-- Name: state_list_state_id_seq; Type: SEQUENCE; Schema: tst; Owner: test_admin
--

CREATE SEQUENCE tst.state_list_state_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.state_list_state_id_seq OWNER TO test_admin;

--
-- Name: state_list_state_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: test_admin
--

ALTER SEQUENCE tst.state_list_state_id_seq OWNED BY tst.state_list.state_id;


--
-- Name: user_info; Type: TABLE; Schema: tst; Owner: test_admin
--

CREATE TABLE tst.user_info (
    user_id integer NOT NULL,
    user_name character varying(250) NOT NULL,
    user_photo bytea
);


ALTER TABLE tst.user_info OWNER TO test_admin;

--
-- Name: user_info_user_id_seq; Type: SEQUENCE; Schema: tst; Owner: test_admin
--

CREATE SEQUENCE tst.user_info_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.user_info_user_id_seq OWNER TO test_admin;

--
-- Name: user_info_user_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: test_admin
--

ALTER SEQUENCE tst.user_info_user_id_seq OWNED BY tst.user_info.user_id;


--
-- Name: users; Type: TABLE; Schema: tst; Owner: test_admin
--

CREATE TABLE tst.users (
    user_id integer NOT NULL,
    login character varying(50) NOT NULL,
    pswd text NOT NULL,
    role_id smallint NOT NULL,
    state_id smallint
);


ALTER TABLE tst.users OWNER TO test_admin;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: tst; Owner: test_admin
--

CREATE SEQUENCE tst.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.users_user_id_seq OWNER TO test_admin;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: test_admin
--

ALTER SEQUENCE tst.users_user_id_seq OWNED BY tst.users.user_id;


--
-- Name: posts post_id; Type: DEFAULT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.posts ALTER COLUMN post_id SET DEFAULT nextval('tst.posts_post_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.roles ALTER COLUMN role_id SET DEFAULT nextval('tst.roles_role_id_seq'::regclass);


--
-- Name: state_list state_id; Type: DEFAULT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.state_list ALTER COLUMN state_id SET DEFAULT nextval('tst.state_list_state_id_seq'::regclass);


--
-- Name: user_info user_id; Type: DEFAULT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.user_info ALTER COLUMN user_id SET DEFAULT nextval('tst.user_info_user_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.users ALTER COLUMN user_id SET DEFAULT nextval('tst.users_user_id_seq'::regclass);


--
-- Data for Name: posts; Type: TABLE DATA; Schema: tst; Owner: test_admin
--

COPY tst.posts (post_id, user_id, post, post_date) FROM stdin;
\.
COPY tst.posts (post_id, user_id, post, post_date) FROM '$$PATH$$/2914.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: tst; Owner: test_admin
--

COPY tst.roles (role_id, role_name, is_admin) FROM stdin;
\.
COPY tst.roles (role_id, role_name, is_admin) FROM '$$PATH$$/2916.dat';

--
-- Data for Name: state_list; Type: TABLE DATA; Schema: tst; Owner: test_admin
--

COPY tst.state_list (state_id, state_name) FROM stdin;
\.
COPY tst.state_list (state_id, state_name) FROM '$$PATH$$/2918.dat';

--
-- Data for Name: user_info; Type: TABLE DATA; Schema: tst; Owner: test_admin
--

COPY tst.user_info (user_id, user_name, user_photo) FROM stdin;
\.
COPY tst.user_info (user_id, user_name, user_photo) FROM '$$PATH$$/2912.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: tst; Owner: test_admin
--

COPY tst.users (user_id, login, pswd, role_id, state_id) FROM stdin;
\.
COPY tst.users (user_id, login, pswd, role_id, state_id) FROM '$$PATH$$/2910.dat';

--
-- Name: posts_post_id_seq; Type: SEQUENCE SET; Schema: tst; Owner: test_admin
--

SELECT pg_catalog.setval('tst.posts_post_id_seq', 4, true);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: tst; Owner: test_admin
--

SELECT pg_catalog.setval('tst.roles_role_id_seq', 2, true);


--
-- Name: state_list_state_id_seq; Type: SEQUENCE SET; Schema: tst; Owner: test_admin
--

SELECT pg_catalog.setval('tst.state_list_state_id_seq', 2, true);


--
-- Name: user_info_user_id_seq; Type: SEQUENCE SET; Schema: tst; Owner: test_admin
--

SELECT pg_catalog.setval('tst.user_info_user_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: tst; Owner: test_admin
--

SELECT pg_catalog.setval('tst.users_user_id_seq', 4, true);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (post_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: state_list state_list_pkey; Type: CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.state_list
    ADD CONSTRAINT state_list_pkey PRIMARY KEY (state_id);


--
-- Name: users unique_login; Type: CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.users
    ADD CONSTRAINT unique_login UNIQUE (login);


--
-- Name: users users_pkey1; Type: CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.users
    ADD CONSTRAINT users_pkey1 PRIMARY KEY (user_id);


--
-- Name: users fk_role_id; Type: FK CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.users
    ADD CONSTRAINT fk_role_id FOREIGN KEY (role_id) REFERENCES tst.roles(role_id) ON UPDATE CASCADE ON DELETE RESTRICT NOT VALID;


--
-- Name: users fk_state_id; Type: FK CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.users
    ADD CONSTRAINT fk_state_id FOREIGN KEY (state_id) REFERENCES tst.state_list(state_id) ON UPDATE CASCADE ON DELETE RESTRICT NOT VALID;


--
-- Name: user_info fk_user_id; Type: FK CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.user_info
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES tst.users(user_id);


--
-- Name: posts fk_user_id; Type: FK CONSTRAINT; Schema: tst; Owner: test_admin
--

ALTER TABLE ONLY tst.posts
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES tst.users(user_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

